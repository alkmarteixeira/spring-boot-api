--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.8
-- Dumped by pg_dump version 9.6.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.answer DROP CONSTRAINT fkfiomvt17psxodcis3d8nmopx8;
ALTER TABLE ONLY public."Tradutores" DROP CONSTRAINT "FK_Tradutores_Enderecos_cd_endereco";
ALTER TABLE ONLY public."Tradutores" DROP CONSTRAINT "FK_Tradutores_Cartorios_cd_cartorio_registro";
ALTER TABLE ONLY public."TradutorIdiomas" DROP CONSTRAINT "FK_TradutorIdiomas_Tradutores_cd_tradutor";
ALTER TABLE ONLY public."TradutorIdiomas" DROP CONSTRAINT "FK_TradutorIdiomas_Idiomas_cd_idioma";
ALTER TABLE ONLY public."TradutorDocumentos" DROP CONSTRAINT "FK_TradutorDocumentos_Tradutores_cd_tradutor";
ALTER TABLE ONLY public."TradutorDocumentos" DROP CONSTRAINT "FK_TradutorDocumentos_TiposDocumentos_cd_tipo_documento";
ALTER TABLE ONLY public."Pessoas" DROP CONSTRAINT "FK_Pessoas_Paises_cd_nacionalidade";
ALTER TABLE ONLY public."Pessoas" DROP CONSTRAINT "FK_Pessoas_Fichas_cd_ficha";
ALTER TABLE ONLY public."Pessoas" DROP CONSTRAINT "FK_Pessoas_EstadosCivil_cd_estado_civil";
ALTER TABLE ONLY public."Pessoas" DROP CONSTRAINT "FK_Pessoas_Enderecos_cd_endereco";
ALTER TABLE ONLY public."Pessoas" DROP CONSTRAINT "FK_Pessoas_Documentos_cd_documento";
ALTER TABLE ONLY public."Pessoas" DROP CONSTRAINT "FK_Pessoas_Cidades_cd_naturalidade";
ALTER TABLE ONLY public."Pessoas" DROP CONSTRAINT "FK_Pessoas_Cartorios_cd_cartorio";
ALTER TABLE ONLY public."Pessoas" DROP CONSTRAINT "FK_Pessoas_Biometrias_cd_biometria";
ALTER TABLE ONLY public."PessoasJuridicas" DROP CONSTRAINT "FK_PessoasJuridicas_Fichas_cd_ficha";
ALTER TABLE ONLY public."PessoasJuridicas" DROP CONSTRAINT "FK_PessoasJuridicas_Fichas_cd_documentospj";
ALTER TABLE ONLY public."PessoasJuridicas" DROP CONSTRAINT "FK_PessoasJuridicas_Enderecos_cd_endereco";
ALTER TABLE ONLY public."PessoasJuridicas" DROP CONSTRAINT "FK_PessoasJuridicas_Cartorios_cd_cartorio";
ALTER TABLE ONLY public."PessoasJuridicasIntegrantes" DROP CONSTRAINT "FK_PessoasJuridicasIntegrantes_PessoasJuridicas_cd_pessoa_jurid";
ALTER TABLE ONLY public."PessoasIrregularidades" DROP CONSTRAINT "FK_PessoasIrregularidades_Cartorios_cd_cartorio_registro";
ALTER TABLE ONLY public."Enderecos" DROP CONSTRAINT "FK_Enderecos_Cidades_cd_cidade";
ALTER TABLE ONLY public."DocumentosPJ" DROP CONSTRAINT "FK_Documentos_Pessoas_cd_documentosPJ";
ALTER TABLE ONLY public."Documentos" DROP CONSTRAINT "FK_Documentos_OrgaosEmissores_cd_orgao_emissor";
ALTER TABLE ONLY public."Cartorios" DROP CONSTRAINT "FK_Cartorios_Cidades_cd_cidade";
DROP INDEX public."IX_Tradutores_cd_endereco";
DROP INDEX public."IX_Tradutores_cd_cartorio_registro";
DROP INDEX public."IX_TradutorIdiomas_cd_tradutor";
DROP INDEX public."IX_TradutorIdiomas_cd_idioma";
DROP INDEX public."IX_TradutorDocumentos_cd_tradutor";
DROP INDEX public."IX_TradutorDocumentos_cd_tipo_documento";
DROP INDEX public."IX_Pessoas_cd_naturalidade";
DROP INDEX public."IX_Pessoas_cd_nacionalidade";
DROP INDEX public."IX_Pessoas_cd_ficha";
DROP INDEX public."IX_Pessoas_cd_estado_civil";
DROP INDEX public."IX_Pessoas_cd_endereco";
DROP INDEX public."IX_Pessoas_cd_documento";
DROP INDEX public."IX_Pessoas_cd_biometria";
DROP INDEX public."IX_PessoasJuridicas_cd_ficha";
DROP INDEX public."IX_PessoasJuridicas_cd_endereco";
DROP INDEX public."IX_PessoasJuridicas_cd_cartorio";
DROP INDEX public."IX_PessoasJuridicasIntegrantes_cd_pessoa_juridica";
DROP INDEX public."IX_PessoasIrregularidades_cd_cartorio_registro";
DROP INDEX public."IX_Enderecos_cd_cidade";
DROP INDEX public."IX_Documentos_cd_orgao_emissor";
DROP INDEX public."IX_Cartorios_cd_cidade";
DROP INDEX public."DocumentosPJ_pessoasjuridicasid_key";
ALTER TABLE ONLY public.question DROP CONSTRAINT question_pkey;
ALTER TABLE ONLY public."Session" DROP CONSTRAINT pk_session;
ALTER TABLE ONLY public."Recebimento" DROP CONSTRAINT pk_recebimento;
ALTER TABLE ONLY public."Configuracao" DROP CONSTRAINT pk_configuracao;
ALTER TABLE ONLY public.answer DROP CONSTRAINT answer_pkey;
ALTER TABLE ONLY public."Cartorios" DROP CONSTRAINT "UK_Cartorio";
ALTER TABLE ONLY public."__EFMigrationsHistory" DROP CONSTRAINT "PK___EFMigrationsHistory";
ALTER TABLE ONLY public."Tradutores" DROP CONSTRAINT "PK_Tradutores";
ALTER TABLE ONLY public."TradutorIdiomas" DROP CONSTRAINT "PK_TradutorIdiomas";
ALTER TABLE ONLY public."TradutorDocumentos" DROP CONSTRAINT "PK_TradutorDocumentos";
ALTER TABLE ONLY public."TiposDocumentos" DROP CONSTRAINT "PK_TiposDocumentos";
ALTER TABLE ONLY public."StoredEvent" DROP CONSTRAINT "PK_StoredEvent";
ALTER TABLE ONLY public."PessoasJuridicasIntegrantes" DROP CONSTRAINT "PK_PessoasJuridicasIntegrantes";
ALTER TABLE ONLY public."PessoasJuridicas" DROP CONSTRAINT "PK_PessoasJuridicas";
ALTER TABLE ONLY public."PessoasIrregularidades" DROP CONSTRAINT "PK_PessoasIrregularidades";
ALTER TABLE ONLY public."Pessoas" DROP CONSTRAINT "PK_Pessoas";
ALTER TABLE ONLY public."Paises" DROP CONSTRAINT "PK_Paises";
ALTER TABLE ONLY public."OrgaosEmissores" DROP CONSTRAINT "PK_OrgaosEmissores";
ALTER TABLE ONLY public."Idiomas" DROP CONSTRAINT "PK_Idiomas";
ALTER TABLE ONLY public."Fichas" DROP CONSTRAINT "PK_Fichas";
ALTER TABLE ONLY public."EstadosCivil" DROP CONSTRAINT "PK_EstadosCivil";
ALTER TABLE ONLY public."Enderecos" DROP CONSTRAINT "PK_Enderecos";
ALTER TABLE ONLY public."DocumentosPJ" DROP CONSTRAINT "PK_DocumentosPJ";
ALTER TABLE ONLY public."Documentos" DROP CONSTRAINT "PK_Documentos";
ALTER TABLE ONLY public."Customers" DROP CONSTRAINT "PK_Customers";
ALTER TABLE ONLY public."Cidades" DROP CONSTRAINT "PK_Cidades";
ALTER TABLE ONLY public."Cartorios" DROP CONSTRAINT "PK_Cartorios";
ALTER TABLE ONLY public."Biometrias" DROP CONSTRAINT "PK_Biometrias";
ALTER TABLE ONLY public."Dashboard" DROP CONSTRAINT "Dashboard_pkey";
ALTER TABLE public."Tradutores" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."TradutorIdiomas" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."TradutorDocumentos" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."TiposDocumentos" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."StoredEvent" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."PessoasJuridicasIntegrantes" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."PessoasJuridicas" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."PessoasIrregularidades" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Pessoas" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Paises" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."OrgaosEmissores" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Idiomas" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Fichas" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."EstadosCivil" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Enderecos" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."DocumentosPJ" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Documentos" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Dashboard" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Customers" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Cidades" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Cartorios" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Biometrias" ALTER COLUMN "Id" DROP DEFAULT;
DROP SEQUENCE public.question_sequence;
DROP TABLE public.question;
DROP SEQUENCE public.answer_sequence;
DROP TABLE public.answer;
DROP TABLE public."__EFMigrationsHistory";
DROP SEQUENCE public."Tradutores_Id_seq";
DROP TABLE public."Tradutores";
DROP SEQUENCE public."TradutorIdiomas_Id_seq";
DROP TABLE public."TradutorIdiomas";
DROP SEQUENCE public."TradutorDocumentos_Id_seq";
DROP TABLE public."TradutorDocumentos";
DROP SEQUENCE public."TiposDocumentos_Id_seq";
DROP TABLE public."TiposDocumentos";
DROP SEQUENCE public."StoredEvent_Id_seq";
DROP TABLE public."StoredEvent";
DROP TABLE public."Session";
DROP TABLE public."Recebimento";
DROP SEQUENCE public."Pessoas_Id_seq";
DROP SEQUENCE public."PessoasJuridicas_Id_seq";
DROP SEQUENCE public."PessoasJuridicasIntegrantes_Id_seq";
DROP TABLE public."PessoasJuridicasIntegrantes";
DROP TABLE public."PessoasJuridicas";
DROP SEQUENCE public."PessoasIrregularidades_Id_seq";
DROP TABLE public."PessoasIrregularidades";
DROP TABLE public."Pessoas";
DROP SEQUENCE public."Paises_Id_seq";
DROP TABLE public."Paises";
DROP SEQUENCE public."OrgaosEmissores_Id_seq";
DROP TABLE public."OrgaosEmissores";
DROP SEQUENCE public."Idiomas_Id_seq";
DROP TABLE public."Idiomas";
DROP SEQUENCE public."Fichas_Id_seq";
DROP TABLE public."Fichas";
DROP SEQUENCE public."EstadosCivil_Id_seq";
DROP TABLE public."EstadosCivil";
DROP SEQUENCE public."Enderecos_Id_seq";
DROP TABLE public."Enderecos";
DROP SEQUENCE public."Documentos_Id_seq";
DROP SEQUENCE public."DocumentosPJ_Id_seq";
DROP TABLE public."DocumentosPJ";
DROP TABLE public."Documentos";
DROP SEQUENCE public."Dashboard_Id_seq1";
DROP SEQUENCE public."Dashboard_Id_seq";
DROP TABLE public."Dashboard";
DROP SEQUENCE public."Customers_Id_seq";
DROP TABLE public."Customers";
DROP TABLE public."Configuracao";
DROP SEQUENCE public."Cidades_Id_seq";
DROP TABLE public."Cidades";
DROP SEQUENCE public."Cartorios_Id_seq";
DROP TABLE public."Cartorios";
DROP SEQUENCE public."Biometrias_Id_seq";
DROP TABLE public."Biometrias";
DROP EXTENSION "uuid-ossp";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Biometrias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Biometrias" (
    "Id" bigint NOT NULL,
    cd_dedo integer NOT NULL,
    imagem_biometria text,
    iso_template text
);


ALTER TABLE "Biometrias" OWNER TO postgres;

--
-- Name: Biometrias_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Biometrias_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Biometrias_Id_seq" OWNER TO postgres;

--
-- Name: Biometrias_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Biometrias_Id_seq" OWNED BY "Biometrias"."Id";


--
-- Name: Cartorios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Cartorios" (
    "Id" bigint NOT NULL,
    cd_cidade bigint NOT NULL,
    cd_cnj integer NOT NULL,
    fl_ativo boolean NOT NULL,
    nm_cartorio text,
    nm_oficial_tabeliao text,
    token text,
    role_consulta boolean DEFAULT false,
    role_insere boolean DEFAULT false,
    usuario text,
    senha text,
    host text
);


ALTER TABLE "Cartorios" OWNER TO postgres;

--
-- Name: Cartorios_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Cartorios_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Cartorios_Id_seq" OWNER TO postgres;

--
-- Name: Cartorios_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Cartorios_Id_seq" OWNED BY "Cartorios"."Id";


--
-- Name: Cidades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Cidades" (
    "Id" bigint NOT NULL,
    cd_cep_cidade integer NOT NULL,
    cd_ibge integer NOT NULL,
    cep text,
    ds_nome text,
    uf text
);


ALTER TABLE "Cidades" OWNER TO postgres;

--
-- Name: Cidades_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Cidades_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Cidades_Id_seq" OWNER TO postgres;

--
-- Name: Cidades_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Cidades_Id_seq" OWNED BY "Cidades"."Id";


--
-- Name: Configuracao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Configuracao" (
    chave text NOT NULL,
    descricao text,
    valor text
);


ALTER TABLE "Configuracao" OWNER TO postgres;

--
-- Name: Customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Customers" (
    "Id" bigint NOT NULL,
    "BirthDate" timestamp without time zone NOT NULL,
    "Email" character varying(100) NOT NULL,
    "Name" character varying(100) NOT NULL
);


ALTER TABLE "Customers" OWNER TO postgres;

--
-- Name: Customers_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Customers_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Customers_Id_seq" OWNER TO postgres;

--
-- Name: Customers_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Customers_Id_seq" OWNED BY "Customers"."Id";


--
-- Name: Dashboard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Dashboard" (
    "Data" date,
    "QtdeRegistros" integer,
    "QtdeConveniados" integer,
    "QtdeNaoConveniados" integer,
    "BdSize" character varying,
    "RepositorioSize" character varying,
    "Id" bigint NOT NULL
);
ALTER TABLE ONLY "Dashboard" ALTER COLUMN "Data" SET STATISTICS 0;
ALTER TABLE ONLY "Dashboard" ALTER COLUMN "QtdeRegistros" SET STATISTICS 0;


ALTER TABLE "Dashboard" OWNER TO postgres;

--
-- Name: Dashboard_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Dashboard_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Dashboard_Id_seq" OWNER TO postgres;

--
-- Name: Dashboard_Id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Dashboard_Id_seq1"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Dashboard_Id_seq1" OWNER TO postgres;

--
-- Name: Dashboard_Id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Dashboard_Id_seq1" OWNED BY "Dashboard"."Id";


--
-- Name: Documentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Documentos" (
    "Id" bigint NOT NULL,
    cd_orgao_emissor bigint,
    dt_emissao date,
    doc_identidade character varying(20),
    imagem_documento text,
    uf_orgao_emissor character varying(2),
    ds_orgao_emissor character varying(60)
);


ALTER TABLE "Documentos" OWNER TO postgres;

--
-- Name: DocumentosPJ; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "DocumentosPJ" (
    "Id" bigint NOT NULL,
    id_pessoa_juridica bigint,
    datadocumento date,
    descricaodocumento character varying(150),
    imagemdocumento text
);


ALTER TABLE "DocumentosPJ" OWNER TO postgres;

--
-- Name: DocumentosPJ_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "DocumentosPJ_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "DocumentosPJ_Id_seq" OWNER TO postgres;

--
-- Name: DocumentosPJ_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "DocumentosPJ_Id_seq" OWNED BY "DocumentosPJ"."Id";


--
-- Name: Documentos_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Documentos_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Documentos_Id_seq" OWNER TO postgres;

--
-- Name: Documentos_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Documentos_Id_seq" OWNED BY "Documentos"."Id";


--
-- Name: Enderecos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Enderecos" (
    "Id" bigint NOT NULL,
    cd_cidade bigint,
    cep character varying(8),
    ds_bairro character varying(40),
    ds_complemento character varying(40),
    ds_endreco character varying(60),
    ds_numero_endereco character varying(10),
    ds_outra_cidade text
);


ALTER TABLE "Enderecos" OWNER TO postgres;

--
-- Name: Enderecos_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Enderecos_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Enderecos_Id_seq" OWNER TO postgres;

--
-- Name: Enderecos_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Enderecos_Id_seq" OWNED BY "Enderecos"."Id";


--
-- Name: EstadosCivil; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "EstadosCivil" (
    "Id" bigint NOT NULL,
    de_estado_civil_fem text,
    de_estado_civil_masc text,
    cd_tj_sc bigint DEFAULT 0
);


ALTER TABLE "EstadosCivil" OWNER TO postgres;

--
-- Name: EstadosCivil_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "EstadosCivil_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "EstadosCivil_Id_seq" OWNER TO postgres;

--
-- Name: EstadosCivil_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "EstadosCivil_Id_seq" OWNED BY "EstadosCivil"."Id";


--
-- Name: Fichas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Fichas" (
    "Id" bigint NOT NULL,
    dt_ficha timestamp without time zone NOT NULL,
    nu_ficha text,
    imagem_ficha text
);


ALTER TABLE "Fichas" OWNER TO postgres;

--
-- Name: Fichas_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Fichas_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Fichas_Id_seq" OWNER TO postgres;

--
-- Name: Fichas_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Fichas_Id_seq" OWNED BY "Fichas"."Id";


--
-- Name: Idiomas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Idiomas" (
    "Id" bigint NOT NULL,
    descricao text
);


ALTER TABLE "Idiomas" OWNER TO postgres;

--
-- Name: Idiomas_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Idiomas_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Idiomas_Id_seq" OWNER TO postgres;

--
-- Name: Idiomas_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Idiomas_Id_seq" OWNED BY "Idiomas"."Id";


--
-- Name: OrgaosEmissores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "OrgaosEmissores" (
    "Id" bigint NOT NULL,
    ds_orgao_emissor text,
    ds_sigla_orgao_emissor text
);


ALTER TABLE "OrgaosEmissores" OWNER TO postgres;

--
-- Name: OrgaosEmissores_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "OrgaosEmissores_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "OrgaosEmissores_Id_seq" OWNER TO postgres;

--
-- Name: OrgaosEmissores_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "OrgaosEmissores_Id_seq" OWNED BY "OrgaosEmissores"."Id";


--
-- Name: Paises; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Paises" (
    "Id" bigint NOT NULL,
    de_nacionalidade_fem text,
    de_nacionalidade_masc text,
    de_pais text,
    sg_pais text
);


ALTER TABLE "Paises" OWNER TO postgres;

--
-- Name: Paises_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Paises_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Paises_Id_seq" OWNER TO postgres;

--
-- Name: Paises_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Paises_Id_seq" OWNED BY "Paises"."Id";


--
-- Name: Pessoas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Pessoas" (
    "Id" bigint NOT NULL,
    cd_biometria bigint,
    cd_documento bigint,
    cd_endereco bigint,
    cd_estado_civil bigint,
    cd_ficha bigint,
    cd_nacionalidade bigint,
    cd_naturalidade bigint,
    cpf character varying(11) NOT NULL,
    de_profissao character varying(40),
    dt_nascimento date NOT NULL,
    email character varying(40),
    imagem_foto character varying,
    nm_mae character varying(80),
    ds_nome character varying(255) NOT NULL,
    nu_celular character varying(15),
    nu_telefone character varying(15),
    ds_observacao character varying,
    nm_pai character varying(80),
    ds_cidade_naturalidade character varying(40),
    uf_naturalidade character varying(2),
    cd_cartorio bigint,
    data_registro timestamp without time zone,
    sexo character(1)
);


ALTER TABLE "Pessoas" OWNER TO postgres;

--
-- Name: PessoasIrregularidades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "PessoasIrregularidades" (
    "Id" bigint NOT NULL,
    cd_cartorio_registro bigint NOT NULL,
    cpf character varying(11) NOT NULL,
    dt_registro timestamp without time zone NOT NULL,
    ds_motivo character varying NOT NULL
);


ALTER TABLE "PessoasIrregularidades" OWNER TO postgres;

--
-- Name: PessoasIrregularidades_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "PessoasIrregularidades_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "PessoasIrregularidades_Id_seq" OWNER TO postgres;

--
-- Name: PessoasIrregularidades_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "PessoasIrregularidades_Id_seq" OWNED BY "PessoasIrregularidades"."Id";


--
-- Name: PessoasJuridicas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "PessoasJuridicas" (
    "Id" bigint NOT NULL,
    cd_cartorio bigint NOT NULL,
    cd_endereco bigint,
    cd_ficha bigint NOT NULL,
    cnpj character varying(14) NOT NULL,
    data_criacao timestamp without time zone NOT NULL,
    data_registro timestamp without time zone NOT NULL,
    data_alteracao timestamp without time zone NOT NULL,
    email character varying(40),
    nu_celular character varying(40),
    nu_telefone character varying(15),
    observacao character varying(255),
    razao_social character varying(120) NOT NULL,
    nome_fantasia character varying(120) NOT NULL,
    cd_documentospj bigint
);


ALTER TABLE "PessoasJuridicas" OWNER TO postgres;

--
-- Name: PessoasJuridicasIntegrantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "PessoasJuridicasIntegrantes" (
    "Id" bigint NOT NULL,
    id_pessoa_juridica bigint NOT NULL,
    cpf character varying(11) NOT NULL,
    doc_identificacao character varying(20),
    ds_orgao_emissor character varying(20),
    nome character varying(60) NOT NULL,
    tipo_integrante integer NOT NULL,
    uf_orgao_emissor character varying(2)
);


ALTER TABLE "PessoasJuridicasIntegrantes" OWNER TO postgres;

--
-- Name: PessoasJuridicasIntegrantes_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "PessoasJuridicasIntegrantes_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "PessoasJuridicasIntegrantes_Id_seq" OWNER TO postgres;

--
-- Name: PessoasJuridicasIntegrantes_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "PessoasJuridicasIntegrantes_Id_seq" OWNED BY "PessoasJuridicasIntegrantes"."Id";


--
-- Name: PessoasJuridicas_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "PessoasJuridicas_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "PessoasJuridicas_Id_seq" OWNER TO postgres;

--
-- Name: PessoasJuridicas_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "PessoasJuridicas_Id_seq" OWNED BY "PessoasJuridicas"."Id";


--
-- Name: Pessoas_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Pessoas_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Pessoas_Id_seq" OWNER TO postgres;

--
-- Name: Pessoas_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Pessoas_Id_seq" OWNED BY "Pessoas"."Id";


--
-- Name: Recebimento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Recebimento" (
    "Id" text NOT NULL,
    data_recebimento timestamp without time zone,
    data_processamento time without time zone,
    total_registros integer,
    mensagem text,
    cd_cartorio integer,
    status integer NOT NULL,
    legado boolean NOT NULL,
    operacao integer NOT NULL
);


ALTER TABLE "Recebimento" OWNER TO postgres;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Session" (
    id text NOT NULL,
    id_cartorio integer NOT NULL,
    data timestamp without time zone,
    host text,
    data_idle timestamp without time zone
);


ALTER TABLE "Session" OWNER TO postgres;

--
-- Name: StoredEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "StoredEvent" (
    "Id" bigint NOT NULL,
    "AggregateId" bigint NOT NULL,
    "Data" text,
    "Action" character varying(100),
    "CreationDate" timestamp without time zone NOT NULL,
    "User" text
);


ALTER TABLE "StoredEvent" OWNER TO postgres;

--
-- Name: StoredEvent_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "StoredEvent_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "StoredEvent_Id_seq" OWNER TO postgres;

--
-- Name: StoredEvent_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "StoredEvent_Id_seq" OWNED BY "StoredEvent"."Id";


--
-- Name: TiposDocumentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "TiposDocumentos" (
    "Id" bigint NOT NULL,
    "Descricao" text
);


ALTER TABLE "TiposDocumentos" OWNER TO postgres;

--
-- Name: TiposDocumentos_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "TiposDocumentos_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "TiposDocumentos_Id_seq" OWNER TO postgres;

--
-- Name: TiposDocumentos_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "TiposDocumentos_Id_seq" OWNED BY "TiposDocumentos"."Id";


--
-- Name: TradutorDocumentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "TradutorDocumentos" (
    "Id" bigint NOT NULL,
    cd_tipo_documento bigint NOT NULL,
    cd_tradutor bigint NOT NULL,
    nm_arquivo text,
    dt_inclusao timestamp without time zone DEFAULT '0001-01-01 00:00:00'::timestamp without time zone NOT NULL,
    path text
);


ALTER TABLE "TradutorDocumentos" OWNER TO postgres;

--
-- Name: TradutorDocumentos_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "TradutorDocumentos_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "TradutorDocumentos_Id_seq" OWNER TO postgres;

--
-- Name: TradutorDocumentos_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "TradutorDocumentos_Id_seq" OWNED BY "TradutorDocumentos"."Id";


--
-- Name: TradutorIdiomas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "TradutorIdiomas" (
    "Id" bigint NOT NULL,
    cd_idioma bigint NOT NULL,
    cd_tradutor bigint NOT NULL
);


ALTER TABLE "TradutorIdiomas" OWNER TO postgres;

--
-- Name: TradutorIdiomas_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "TradutorIdiomas_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "TradutorIdiomas_Id_seq" OWNER TO postgres;

--
-- Name: TradutorIdiomas_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "TradutorIdiomas_Id_seq" OWNED BY "TradutorIdiomas"."Id";


--
-- Name: Tradutores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "Tradutores" (
    "Id" bigint NOT NULL,
    cd_endereco bigint,
    cpf text,
    email text,
    matricula text,
    nome text,
    nu_celular text,
    nu_telefone text,
    cd_cartorio_registro bigint
);


ALTER TABLE "Tradutores" OWNER TO postgres;

--
-- Name: Tradutores_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Tradutores_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Tradutores_Id_seq" OWNER TO postgres;

--
-- Name: Tradutores_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Tradutores_Id_seq" OWNED BY "Tradutores"."Id";


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE "__EFMigrationsHistory" OWNER TO postgres;

--
-- Name: answer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE answer (
    id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    text text,
    question_id bigint NOT NULL
);


ALTER TABLE answer OWNER TO postgres;

--
-- Name: answer_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE answer_sequence
    START WITH 1000
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE answer_sequence OWNER TO postgres;

--
-- Name: question; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE question (
    id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    description text,
    title character varying(100)
);


ALTER TABLE question OWNER TO postgres;

--
-- Name: question_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE question_sequence
    START WITH 1000
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE question_sequence OWNER TO postgres;

--
-- Name: Biometrias Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Biometrias" ALTER COLUMN "Id" SET DEFAULT nextval('"Biometrias_Id_seq"'::regclass);


--
-- Name: Cartorios Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Cartorios" ALTER COLUMN "Id" SET DEFAULT nextval('"Cartorios_Id_seq"'::regclass);


--
-- Name: Cidades Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Cidades" ALTER COLUMN "Id" SET DEFAULT nextval('"Cidades_Id_seq"'::regclass);


--
-- Name: Customers Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Customers" ALTER COLUMN "Id" SET DEFAULT nextval('"Customers_Id_seq"'::regclass);


--
-- Name: Dashboard Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Dashboard" ALTER COLUMN "Id" SET DEFAULT nextval('"Dashboard_Id_seq1"'::regclass);


--
-- Name: Documentos Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Documentos" ALTER COLUMN "Id" SET DEFAULT nextval('"Documentos_Id_seq"'::regclass);


--
-- Name: DocumentosPJ Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "DocumentosPJ" ALTER COLUMN "Id" SET DEFAULT nextval('"DocumentosPJ_Id_seq"'::regclass);


--
-- Name: Enderecos Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Enderecos" ALTER COLUMN "Id" SET DEFAULT nextval('"Enderecos_Id_seq"'::regclass);


--
-- Name: EstadosCivil Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "EstadosCivil" ALTER COLUMN "Id" SET DEFAULT nextval('"EstadosCivil_Id_seq"'::regclass);


--
-- Name: Fichas Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Fichas" ALTER COLUMN "Id" SET DEFAULT nextval('"Fichas_Id_seq"'::regclass);


--
-- Name: Idiomas Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Idiomas" ALTER COLUMN "Id" SET DEFAULT nextval('"Idiomas_Id_seq"'::regclass);


--
-- Name: OrgaosEmissores Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "OrgaosEmissores" ALTER COLUMN "Id" SET DEFAULT nextval('"OrgaosEmissores_Id_seq"'::regclass);


--
-- Name: Paises Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Paises" ALTER COLUMN "Id" SET DEFAULT nextval('"Paises_Id_seq"'::regclass);


--
-- Name: Pessoas Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Pessoas" ALTER COLUMN "Id" SET DEFAULT nextval('"Pessoas_Id_seq"'::regclass);


--
-- Name: PessoasIrregularidades Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasIrregularidades" ALTER COLUMN "Id" SET DEFAULT nextval('"PessoasIrregularidades_Id_seq"'::regclass);


--
-- Name: PessoasJuridicas Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasJuridicas" ALTER COLUMN "Id" SET DEFAULT nextval('"PessoasJuridicas_Id_seq"'::regclass);


--
-- Name: PessoasJuridicasIntegrantes Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasJuridicasIntegrantes" ALTER COLUMN "Id" SET DEFAULT nextval('"PessoasJuridicasIntegrantes_Id_seq"'::regclass);


--
-- Name: StoredEvent Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "StoredEvent" ALTER COLUMN "Id" SET DEFAULT nextval('"StoredEvent_Id_seq"'::regclass);


--
-- Name: TiposDocumentos Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "TiposDocumentos" ALTER COLUMN "Id" SET DEFAULT nextval('"TiposDocumentos_Id_seq"'::regclass);


--
-- Name: TradutorDocumentos Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "TradutorDocumentos" ALTER COLUMN "Id" SET DEFAULT nextval('"TradutorDocumentos_Id_seq"'::regclass);


--
-- Name: TradutorIdiomas Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "TradutorIdiomas" ALTER COLUMN "Id" SET DEFAULT nextval('"TradutorIdiomas_Id_seq"'::regclass);


--
-- Name: Tradutores Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Tradutores" ALTER COLUMN "Id" SET DEFAULT nextval('"Tradutores_Id_seq"'::regclass);


--
-- Data for Name: Biometrias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Biometrias" ("Id", cd_dedo, imagem_biometria, iso_template) FROM stdin;
\.
COPY "Biometrias" ("Id", cd_dedo, imagem_biometria, iso_template) FROM '$$PATH$$/2440.dat';

--
-- Name: Biometrias_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Biometrias_Id_seq"', 6, true);


--
-- Data for Name: Cartorios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Cartorios" ("Id", cd_cidade, cd_cnj, fl_ativo, nm_cartorio, nm_oficial_tabeliao, token, role_consulta, role_insere, usuario, senha, host) FROM stdin;
\.
COPY "Cartorios" ("Id", cd_cidade, cd_cnj, fl_ativo, nm_cartorio, nm_oficial_tabeliao, token, role_consulta, role_insere, usuario, senha, host) FROM '$$PATH$$/2442.dat';

--
-- Name: Cartorios_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Cartorios_Id_seq"', 7, true);


--
-- Data for Name: Cidades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Cidades" ("Id", cd_cep_cidade, cd_ibge, cep, ds_nome, uf) FROM stdin;
\.
COPY "Cidades" ("Id", cd_cep_cidade, cd_ibge, cep, ds_nome, uf) FROM '$$PATH$$/2444.dat';

--
-- Name: Cidades_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Cidades_Id_seq"', 1, false);


--
-- Data for Name: Configuracao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Configuracao" (chave, descricao, valor) FROM stdin;
\.
COPY "Configuracao" (chave, descricao, valor) FROM '$$PATH$$/2446.dat';

--
-- Data for Name: Customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Customers" ("Id", "BirthDate", "Email", "Name") FROM stdin;
\.
COPY "Customers" ("Id", "BirthDate", "Email", "Name") FROM '$$PATH$$/2447.dat';

--
-- Name: Customers_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Customers_Id_seq"', 1, false);


--
-- Data for Name: Dashboard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Dashboard" ("Data", "QtdeRegistros", "QtdeConveniados", "QtdeNaoConveniados", "BdSize", "RepositorioSize", "Id") FROM stdin;
\.
COPY "Dashboard" ("Data", "QtdeRegistros", "QtdeConveniados", "QtdeNaoConveniados", "BdSize", "RepositorioSize", "Id") FROM '$$PATH$$/2449.dat';

--
-- Name: Dashboard_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Dashboard_Id_seq"', 1, false);


--
-- Name: Dashboard_Id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Dashboard_Id_seq1"', 1, false);


--
-- Data for Name: Documentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Documentos" ("Id", cd_orgao_emissor, dt_emissao, doc_identidade, imagem_documento, uf_orgao_emissor, ds_orgao_emissor) FROM stdin;
\.
COPY "Documentos" ("Id", cd_orgao_emissor, dt_emissao, doc_identidade, imagem_documento, uf_orgao_emissor, ds_orgao_emissor) FROM '$$PATH$$/2452.dat';

--
-- Data for Name: DocumentosPJ; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "DocumentosPJ" ("Id", id_pessoa_juridica, datadocumento, descricaodocumento, imagemdocumento) FROM stdin;
\.
COPY "DocumentosPJ" ("Id", id_pessoa_juridica, datadocumento, descricaodocumento, imagemdocumento) FROM '$$PATH$$/2453.dat';

--
-- Name: DocumentosPJ_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"DocumentosPJ_Id_seq"', 1, false);


--
-- Name: Documentos_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Documentos_Id_seq"', 6, true);


--
-- Data for Name: Enderecos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Enderecos" ("Id", cd_cidade, cep, ds_bairro, ds_complemento, ds_endreco, ds_numero_endereco, ds_outra_cidade) FROM stdin;
\.
COPY "Enderecos" ("Id", cd_cidade, cep, ds_bairro, ds_complemento, ds_endreco, ds_numero_endereco, ds_outra_cidade) FROM '$$PATH$$/2456.dat';

--
-- Name: Enderecos_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Enderecos_Id_seq"', 6, true);


--
-- Data for Name: EstadosCivil; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "EstadosCivil" ("Id", de_estado_civil_fem, de_estado_civil_masc, cd_tj_sc) FROM stdin;
\.
COPY "EstadosCivil" ("Id", de_estado_civil_fem, de_estado_civil_masc, cd_tj_sc) FROM '$$PATH$$/2458.dat';

--
-- Name: EstadosCivil_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"EstadosCivil_Id_seq"', 1, false);


--
-- Data for Name: Fichas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Fichas" ("Id", dt_ficha, nu_ficha, imagem_ficha) FROM stdin;
\.
COPY "Fichas" ("Id", dt_ficha, nu_ficha, imagem_ficha) FROM '$$PATH$$/2460.dat';

--
-- Name: Fichas_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Fichas_Id_seq"', 6, true);


--
-- Data for Name: Idiomas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Idiomas" ("Id", descricao) FROM stdin;
\.
COPY "Idiomas" ("Id", descricao) FROM '$$PATH$$/2462.dat';

--
-- Name: Idiomas_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Idiomas_Id_seq"', 1, false);


--
-- Data for Name: OrgaosEmissores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "OrgaosEmissores" ("Id", ds_orgao_emissor, ds_sigla_orgao_emissor) FROM stdin;
\.
COPY "OrgaosEmissores" ("Id", ds_orgao_emissor, ds_sigla_orgao_emissor) FROM '$$PATH$$/2464.dat';

--
-- Name: OrgaosEmissores_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"OrgaosEmissores_Id_seq"', 1, false);


--
-- Data for Name: Paises; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Paises" ("Id", de_nacionalidade_fem, de_nacionalidade_masc, de_pais, sg_pais) FROM stdin;
\.
COPY "Paises" ("Id", de_nacionalidade_fem, de_nacionalidade_masc, de_pais, sg_pais) FROM '$$PATH$$/2466.dat';

--
-- Name: Paises_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Paises_Id_seq"', 1, false);


--
-- Data for Name: Pessoas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Pessoas" ("Id", cd_biometria, cd_documento, cd_endereco, cd_estado_civil, cd_ficha, cd_nacionalidade, cd_naturalidade, cpf, de_profissao, dt_nascimento, email, imagem_foto, nm_mae, ds_nome, nu_celular, nu_telefone, ds_observacao, nm_pai, ds_cidade_naturalidade, uf_naturalidade, cd_cartorio, data_registro, sexo) FROM stdin;
\.
COPY "Pessoas" ("Id", cd_biometria, cd_documento, cd_endereco, cd_estado_civil, cd_ficha, cd_nacionalidade, cd_naturalidade, cpf, de_profissao, dt_nascimento, email, imagem_foto, nm_mae, ds_nome, nu_celular, nu_telefone, ds_observacao, nm_pai, ds_cidade_naturalidade, uf_naturalidade, cd_cartorio, data_registro, sexo) FROM '$$PATH$$/2468.dat';

--
-- Data for Name: PessoasIrregularidades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "PessoasIrregularidades" ("Id", cd_cartorio_registro, cpf, dt_registro, ds_motivo) FROM stdin;
\.
COPY "PessoasIrregularidades" ("Id", cd_cartorio_registro, cpf, dt_registro, ds_motivo) FROM '$$PATH$$/2469.dat';

--
-- Name: PessoasIrregularidades_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"PessoasIrregularidades_Id_seq"', 1, false);


--
-- Data for Name: PessoasJuridicas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "PessoasJuridicas" ("Id", cd_cartorio, cd_endereco, cd_ficha, cnpj, data_criacao, data_registro, data_alteracao, email, nu_celular, nu_telefone, observacao, razao_social, nome_fantasia, cd_documentospj) FROM stdin;
\.
COPY "PessoasJuridicas" ("Id", cd_cartorio, cd_endereco, cd_ficha, cnpj, data_criacao, data_registro, data_alteracao, email, nu_celular, nu_telefone, observacao, razao_social, nome_fantasia, cd_documentospj) FROM '$$PATH$$/2471.dat';

--
-- Data for Name: PessoasJuridicasIntegrantes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "PessoasJuridicasIntegrantes" ("Id", id_pessoa_juridica, cpf, doc_identificacao, ds_orgao_emissor, nome, tipo_integrante, uf_orgao_emissor) FROM stdin;
\.
COPY "PessoasJuridicasIntegrantes" ("Id", id_pessoa_juridica, cpf, doc_identificacao, ds_orgao_emissor, nome, tipo_integrante, uf_orgao_emissor) FROM '$$PATH$$/2472.dat';

--
-- Name: PessoasJuridicasIntegrantes_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"PessoasJuridicasIntegrantes_Id_seq"', 1, false);


--
-- Name: PessoasJuridicas_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"PessoasJuridicas_Id_seq"', 1, false);


--
-- Name: Pessoas_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Pessoas_Id_seq"', 4, true);


--
-- Data for Name: Recebimento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Recebimento" ("Id", data_recebimento, data_processamento, total_registros, mensagem, cd_cartorio, status, legado, operacao) FROM stdin;
\.
COPY "Recebimento" ("Id", data_recebimento, data_processamento, total_registros, mensagem, cd_cartorio, status, legado, operacao) FROM '$$PATH$$/2476.dat';

--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Session" (id, id_cartorio, data, host, data_idle) FROM stdin;
\.
COPY "Session" (id, id_cartorio, data, host, data_idle) FROM '$$PATH$$/2477.dat';

--
-- Data for Name: StoredEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "StoredEvent" ("Id", "AggregateId", "Data", "Action", "CreationDate", "User") FROM stdin;
\.
COPY "StoredEvent" ("Id", "AggregateId", "Data", "Action", "CreationDate", "User") FROM '$$PATH$$/2478.dat';

--
-- Name: StoredEvent_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"StoredEvent_Id_seq"', 1, false);


--
-- Data for Name: TiposDocumentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "TiposDocumentos" ("Id", "Descricao") FROM stdin;
\.
COPY "TiposDocumentos" ("Id", "Descricao") FROM '$$PATH$$/2480.dat';

--
-- Name: TiposDocumentos_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"TiposDocumentos_Id_seq"', 1, false);


--
-- Data for Name: TradutorDocumentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "TradutorDocumentos" ("Id", cd_tipo_documento, cd_tradutor, nm_arquivo, dt_inclusao, path) FROM stdin;
\.
COPY "TradutorDocumentos" ("Id", cd_tipo_documento, cd_tradutor, nm_arquivo, dt_inclusao, path) FROM '$$PATH$$/2482.dat';

--
-- Name: TradutorDocumentos_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"TradutorDocumentos_Id_seq"', 1, false);


--
-- Data for Name: TradutorIdiomas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "TradutorIdiomas" ("Id", cd_idioma, cd_tradutor) FROM stdin;
\.
COPY "TradutorIdiomas" ("Id", cd_idioma, cd_tradutor) FROM '$$PATH$$/2484.dat';

--
-- Name: TradutorIdiomas_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"TradutorIdiomas_Id_seq"', 1, false);


--
-- Data for Name: Tradutores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Tradutores" ("Id", cd_endereco, cpf, email, matricula, nome, nu_celular, nu_telefone, cd_cartorio_registro) FROM stdin;
\.
COPY "Tradutores" ("Id", cd_endereco, cpf, email, matricula, nome, nu_celular, nu_telefone, cd_cartorio_registro) FROM '$$PATH$$/2486.dat';

--
-- Name: Tradutores_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Tradutores_Id_seq"', 1, false);


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
\.
COPY "__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM '$$PATH$$/2488.dat';

--
-- Data for Name: answer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY answer (id, created_at, updated_at, text, question_id) FROM stdin;
\.
COPY answer (id, created_at, updated_at, text, question_id) FROM '$$PATH$$/2491.dat';

--
-- Name: answer_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('answer_sequence', 1000, false);


--
-- Data for Name: question; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY question (id, created_at, updated_at, description, title) FROM stdin;
\.
COPY question (id, created_at, updated_at, description, title) FROM '$$PATH$$/2492.dat';

--
-- Name: question_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('question_sequence', 1000, false);


--
-- Name: Dashboard Dashboard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Dashboard"
    ADD CONSTRAINT "Dashboard_pkey" PRIMARY KEY ("Id");


--
-- Name: Biometrias PK_Biometrias; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Biometrias"
    ADD CONSTRAINT "PK_Biometrias" PRIMARY KEY ("Id");


--
-- Name: Cartorios PK_Cartorios; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Cartorios"
    ADD CONSTRAINT "PK_Cartorios" PRIMARY KEY ("Id");


--
-- Name: Cidades PK_Cidades; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Cidades"
    ADD CONSTRAINT "PK_Cidades" PRIMARY KEY ("Id");


--
-- Name: Customers PK_Customers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Customers"
    ADD CONSTRAINT "PK_Customers" PRIMARY KEY ("Id");


--
-- Name: Documentos PK_Documentos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Documentos"
    ADD CONSTRAINT "PK_Documentos" PRIMARY KEY ("Id");


--
-- Name: DocumentosPJ PK_DocumentosPJ; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "DocumentosPJ"
    ADD CONSTRAINT "PK_DocumentosPJ" PRIMARY KEY ("Id");


--
-- Name: Enderecos PK_Enderecos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Enderecos"
    ADD CONSTRAINT "PK_Enderecos" PRIMARY KEY ("Id");


--
-- Name: EstadosCivil PK_EstadosCivil; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "EstadosCivil"
    ADD CONSTRAINT "PK_EstadosCivil" PRIMARY KEY ("Id");


--
-- Name: Fichas PK_Fichas; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Fichas"
    ADD CONSTRAINT "PK_Fichas" PRIMARY KEY ("Id");


--
-- Name: Idiomas PK_Idiomas; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Idiomas"
    ADD CONSTRAINT "PK_Idiomas" PRIMARY KEY ("Id");


--
-- Name: OrgaosEmissores PK_OrgaosEmissores; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "OrgaosEmissores"
    ADD CONSTRAINT "PK_OrgaosEmissores" PRIMARY KEY ("Id");


--
-- Name: Paises PK_Paises; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Paises"
    ADD CONSTRAINT "PK_Paises" PRIMARY KEY ("Id");


--
-- Name: Pessoas PK_Pessoas; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Pessoas"
    ADD CONSTRAINT "PK_Pessoas" PRIMARY KEY ("Id");


--
-- Name: PessoasIrregularidades PK_PessoasIrregularidades; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasIrregularidades"
    ADD CONSTRAINT "PK_PessoasIrregularidades" PRIMARY KEY ("Id");


--
-- Name: PessoasJuridicas PK_PessoasJuridicas; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasJuridicas"
    ADD CONSTRAINT "PK_PessoasJuridicas" PRIMARY KEY ("Id");


--
-- Name: PessoasJuridicasIntegrantes PK_PessoasJuridicasIntegrantes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasJuridicasIntegrantes"
    ADD CONSTRAINT "PK_PessoasJuridicasIntegrantes" PRIMARY KEY ("Id");


--
-- Name: StoredEvent PK_StoredEvent; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "StoredEvent"
    ADD CONSTRAINT "PK_StoredEvent" PRIMARY KEY ("Id");


--
-- Name: TiposDocumentos PK_TiposDocumentos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "TiposDocumentos"
    ADD CONSTRAINT "PK_TiposDocumentos" PRIMARY KEY ("Id");


--
-- Name: TradutorDocumentos PK_TradutorDocumentos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "TradutorDocumentos"
    ADD CONSTRAINT "PK_TradutorDocumentos" PRIMARY KEY ("Id");


--
-- Name: TradutorIdiomas PK_TradutorIdiomas; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "TradutorIdiomas"
    ADD CONSTRAINT "PK_TradutorIdiomas" PRIMARY KEY ("Id");


--
-- Name: Tradutores PK_Tradutores; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Tradutores"
    ADD CONSTRAINT "PK_Tradutores" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: Cartorios UK_Cartorio; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Cartorios"
    ADD CONSTRAINT "UK_Cartorio" UNIQUE (token);


--
-- Name: answer answer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY answer
    ADD CONSTRAINT answer_pkey PRIMARY KEY (id);


--
-- Name: Configuracao pk_configuracao; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Configuracao"
    ADD CONSTRAINT pk_configuracao PRIMARY KEY (chave);


--
-- Name: Recebimento pk_recebimento; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Recebimento"
    ADD CONSTRAINT pk_recebimento PRIMARY KEY ("Id");


--
-- Name: Session pk_session; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Session"
    ADD CONSTRAINT pk_session PRIMARY KEY (id);


--
-- Name: question question_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY question
    ADD CONSTRAINT question_pkey PRIMARY KEY (id);


--
-- Name: DocumentosPJ_pessoasjuridicasid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DocumentosPJ_pessoasjuridicasid_key" ON public."DocumentosPJ" USING btree (id_pessoa_juridica);


--
-- Name: IX_Cartorios_cd_cidade; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Cartorios_cd_cidade" ON public."Cartorios" USING btree (cd_cidade);


--
-- Name: IX_Documentos_cd_orgao_emissor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Documentos_cd_orgao_emissor" ON public."Documentos" USING btree (cd_orgao_emissor);


--
-- Name: IX_Enderecos_cd_cidade; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Enderecos_cd_cidade" ON public."Enderecos" USING btree (cd_cidade);


--
-- Name: IX_PessoasIrregularidades_cd_cartorio_registro; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_PessoasIrregularidades_cd_cartorio_registro" ON public."PessoasIrregularidades" USING btree (cd_cartorio_registro);


--
-- Name: IX_PessoasJuridicasIntegrantes_cd_pessoa_juridica; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_PessoasJuridicasIntegrantes_cd_pessoa_juridica" ON public."PessoasJuridicasIntegrantes" USING btree (id_pessoa_juridica);


--
-- Name: IX_PessoasJuridicas_cd_cartorio; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_PessoasJuridicas_cd_cartorio" ON public."PessoasJuridicas" USING btree (cd_cartorio);


--
-- Name: IX_PessoasJuridicas_cd_endereco; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_PessoasJuridicas_cd_endereco" ON public."PessoasJuridicas" USING btree (cd_endereco);


--
-- Name: IX_PessoasJuridicas_cd_ficha; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_PessoasJuridicas_cd_ficha" ON public."PessoasJuridicas" USING btree (cd_ficha);


--
-- Name: IX_Pessoas_cd_biometria; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Pessoas_cd_biometria" ON public."Pessoas" USING btree (cd_biometria);


--
-- Name: IX_Pessoas_cd_documento; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Pessoas_cd_documento" ON public."Pessoas" USING btree (cd_documento);


--
-- Name: IX_Pessoas_cd_endereco; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Pessoas_cd_endereco" ON public."Pessoas" USING btree (cd_endereco);


--
-- Name: IX_Pessoas_cd_estado_civil; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Pessoas_cd_estado_civil" ON public."Pessoas" USING btree (cd_estado_civil);


--
-- Name: IX_Pessoas_cd_ficha; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Pessoas_cd_ficha" ON public."Pessoas" USING btree (cd_ficha);


--
-- Name: IX_Pessoas_cd_nacionalidade; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Pessoas_cd_nacionalidade" ON public."Pessoas" USING btree (cd_nacionalidade);


--
-- Name: IX_Pessoas_cd_naturalidade; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Pessoas_cd_naturalidade" ON public."Pessoas" USING btree (cd_naturalidade);


--
-- Name: IX_TradutorDocumentos_cd_tipo_documento; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_TradutorDocumentos_cd_tipo_documento" ON public."TradutorDocumentos" USING btree (cd_tipo_documento);


--
-- Name: IX_TradutorDocumentos_cd_tradutor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_TradutorDocumentos_cd_tradutor" ON public."TradutorDocumentos" USING btree (cd_tradutor);


--
-- Name: IX_TradutorIdiomas_cd_idioma; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_TradutorIdiomas_cd_idioma" ON public."TradutorIdiomas" USING btree (cd_idioma);


--
-- Name: IX_TradutorIdiomas_cd_tradutor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_TradutorIdiomas_cd_tradutor" ON public."TradutorIdiomas" USING btree (cd_tradutor);


--
-- Name: IX_Tradutores_cd_cartorio_registro; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Tradutores_cd_cartorio_registro" ON public."Tradutores" USING btree (cd_cartorio_registro);


--
-- Name: IX_Tradutores_cd_endereco; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Tradutores_cd_endereco" ON public."Tradutores" USING btree (cd_endereco);


--
-- Name: Cartorios FK_Cartorios_Cidades_cd_cidade; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Cartorios"
    ADD CONSTRAINT "FK_Cartorios_Cidades_cd_cidade" FOREIGN KEY (cd_cidade) REFERENCES "Cidades"("Id") ON DELETE CASCADE;


--
-- Name: Documentos FK_Documentos_OrgaosEmissores_cd_orgao_emissor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Documentos"
    ADD CONSTRAINT "FK_Documentos_OrgaosEmissores_cd_orgao_emissor" FOREIGN KEY (cd_orgao_emissor) REFERENCES "OrgaosEmissores"("Id");


--
-- Name: DocumentosPJ FK_Documentos_Pessoas_cd_documentosPJ; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "DocumentosPJ"
    ADD CONSTRAINT "FK_Documentos_Pessoas_cd_documentosPJ" FOREIGN KEY (id_pessoa_juridica) REFERENCES "Pessoas"("Id");


--
-- Name: Enderecos FK_Enderecos_Cidades_cd_cidade; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Enderecos"
    ADD CONSTRAINT "FK_Enderecos_Cidades_cd_cidade" FOREIGN KEY (cd_cidade) REFERENCES "Cidades"("Id");


--
-- Name: PessoasIrregularidades FK_PessoasIrregularidades_Cartorios_cd_cartorio_registro; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasIrregularidades"
    ADD CONSTRAINT "FK_PessoasIrregularidades_Cartorios_cd_cartorio_registro" FOREIGN KEY (cd_cartorio_registro) REFERENCES "Cartorios"("Id") ON DELETE CASCADE;


--
-- Name: PessoasJuridicasIntegrantes FK_PessoasJuridicasIntegrantes_PessoasJuridicas_cd_pessoa_jurid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasJuridicasIntegrantes"
    ADD CONSTRAINT "FK_PessoasJuridicasIntegrantes_PessoasJuridicas_cd_pessoa_jurid" FOREIGN KEY (id_pessoa_juridica) REFERENCES "PessoasJuridicas"("Id") ON DELETE CASCADE;


--
-- Name: PessoasJuridicas FK_PessoasJuridicas_Cartorios_cd_cartorio; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasJuridicas"
    ADD CONSTRAINT "FK_PessoasJuridicas_Cartorios_cd_cartorio" FOREIGN KEY (cd_cartorio) REFERENCES "Cartorios"("Id") ON DELETE CASCADE;


--
-- Name: PessoasJuridicas FK_PessoasJuridicas_Enderecos_cd_endereco; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasJuridicas"
    ADD CONSTRAINT "FK_PessoasJuridicas_Enderecos_cd_endereco" FOREIGN KEY (cd_endereco) REFERENCES "Enderecos"("Id");


--
-- Name: PessoasJuridicas FK_PessoasJuridicas_Fichas_cd_documentospj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasJuridicas"
    ADD CONSTRAINT "FK_PessoasJuridicas_Fichas_cd_documentospj" FOREIGN KEY (cd_documentospj) REFERENCES "DocumentosPJ"("Id");


--
-- Name: PessoasJuridicas FK_PessoasJuridicas_Fichas_cd_ficha; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "PessoasJuridicas"
    ADD CONSTRAINT "FK_PessoasJuridicas_Fichas_cd_ficha" FOREIGN KEY (cd_ficha) REFERENCES "Fichas"("Id") ON DELETE CASCADE;


--
-- Name: Pessoas FK_Pessoas_Biometrias_cd_biometria; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Pessoas"
    ADD CONSTRAINT "FK_Pessoas_Biometrias_cd_biometria" FOREIGN KEY (cd_biometria) REFERENCES "Biometrias"("Id");


--
-- Name: Pessoas FK_Pessoas_Cartorios_cd_cartorio; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Pessoas"
    ADD CONSTRAINT "FK_Pessoas_Cartorios_cd_cartorio" FOREIGN KEY (cd_cartorio) REFERENCES "Cartorios"("Id");


--
-- Name: Pessoas FK_Pessoas_Cidades_cd_naturalidade; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Pessoas"
    ADD CONSTRAINT "FK_Pessoas_Cidades_cd_naturalidade" FOREIGN KEY (cd_naturalidade) REFERENCES "Cidades"("Id");


--
-- Name: Pessoas FK_Pessoas_Documentos_cd_documento; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Pessoas"
    ADD CONSTRAINT "FK_Pessoas_Documentos_cd_documento" FOREIGN KEY (cd_documento) REFERENCES "Documentos"("Id");


--
-- Name: Pessoas FK_Pessoas_Enderecos_cd_endereco; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Pessoas"
    ADD CONSTRAINT "FK_Pessoas_Enderecos_cd_endereco" FOREIGN KEY (cd_endereco) REFERENCES "Enderecos"("Id");


--
-- Name: Pessoas FK_Pessoas_EstadosCivil_cd_estado_civil; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Pessoas"
    ADD CONSTRAINT "FK_Pessoas_EstadosCivil_cd_estado_civil" FOREIGN KEY (cd_estado_civil) REFERENCES "EstadosCivil"("Id");


--
-- Name: Pessoas FK_Pessoas_Fichas_cd_ficha; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Pessoas"
    ADD CONSTRAINT "FK_Pessoas_Fichas_cd_ficha" FOREIGN KEY (cd_ficha) REFERENCES "Fichas"("Id");


--
-- Name: Pessoas FK_Pessoas_Paises_cd_nacionalidade; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Pessoas"
    ADD CONSTRAINT "FK_Pessoas_Paises_cd_nacionalidade" FOREIGN KEY (cd_nacionalidade) REFERENCES "Paises"("Id");


--
-- Name: TradutorDocumentos FK_TradutorDocumentos_TiposDocumentos_cd_tipo_documento; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "TradutorDocumentos"
    ADD CONSTRAINT "FK_TradutorDocumentos_TiposDocumentos_cd_tipo_documento" FOREIGN KEY (cd_tipo_documento) REFERENCES "TiposDocumentos"("Id") ON DELETE CASCADE;


--
-- Name: TradutorDocumentos FK_TradutorDocumentos_Tradutores_cd_tradutor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "TradutorDocumentos"
    ADD CONSTRAINT "FK_TradutorDocumentos_Tradutores_cd_tradutor" FOREIGN KEY (cd_tradutor) REFERENCES "Tradutores"("Id") ON DELETE CASCADE;


--
-- Name: TradutorIdiomas FK_TradutorIdiomas_Idiomas_cd_idioma; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "TradutorIdiomas"
    ADD CONSTRAINT "FK_TradutorIdiomas_Idiomas_cd_idioma" FOREIGN KEY (cd_idioma) REFERENCES "Idiomas"("Id") ON DELETE CASCADE;


--
-- Name: TradutorIdiomas FK_TradutorIdiomas_Tradutores_cd_tradutor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "TradutorIdiomas"
    ADD CONSTRAINT "FK_TradutorIdiomas_Tradutores_cd_tradutor" FOREIGN KEY (cd_tradutor) REFERENCES "Tradutores"("Id") ON DELETE CASCADE;


--
-- Name: Tradutores FK_Tradutores_Cartorios_cd_cartorio_registro; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Tradutores"
    ADD CONSTRAINT "FK_Tradutores_Cartorios_cd_cartorio_registro" FOREIGN KEY (cd_cartorio_registro) REFERENCES "Cartorios"("Id");


--
-- Name: Tradutores FK_Tradutores_Enderecos_cd_endereco; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "Tradutores"
    ADD CONSTRAINT "FK_Tradutores_Enderecos_cd_endereco" FOREIGN KEY (cd_endereco) REFERENCES "Enderecos"("Id");


--
-- Name: answer fkfiomvt17psxodcis3d8nmopx8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY answer
    ADD CONSTRAINT fkfiomvt17psxodcis3d8nmopx8 FOREIGN KEY (question_id) REFERENCES question(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

